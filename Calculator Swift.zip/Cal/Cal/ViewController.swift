//
//  ViewController.swift
//  Calculator
//
//  Created by Meghansh Kaushik on 09/08/18.
//  Copyright © 2018 Meghansh Kaushik. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    var OnScreen:Double = 0;
    var  preNumber:Double = 0;
    var perMath = false
    var op = 0;
    
    
    @IBOutlet weak var label: UILabel!
    
    @IBAction func numbers(_ sender: UIButton)
    {
        if perMath == true
        {
            label.text = String(sender.tag-1)
        OnScreen = Double(label.text!)!
            perMath = false
        }
        else
        {
            label.text = label.text! + String(sender.tag-1)
            OnScreen = Double(label.text!)!
        }
    }

    
    @IBAction func buttons(_ sender: UIButton)
    {
        if label.text != "" && sender.tag != 11 && sender.tag != 16
        {
            preNumber = Double(label.text!)!
            
            if sender.tag==12// Divide
            {
                label.text = "/";
            }
            if sender.tag==13// Multiply
            {
                label.text = "x";
            }
            if sender.tag==14// Substract
            {
                label.text = "-";
            }
            if sender.tag==15// Add
            {
                label.text = "+";
            }
            
            op = sender.tag
            perMath = true;
        }
        else if sender.tag == 16
        {
            if op == 12
            {
               label.text = String(preNumber / OnScreen)
            }
           else if op == 13
            {
                label.text = String(preNumber * OnScreen)
            }
           else if op == 14
            {
                 label.text = String(preNumber - OnScreen)
            }
           else if op == 15
            {
              label.text = String(preNumber + OnScreen)
            }
        }
        else if sender.tag == 11
        {
            label.text = ""
            preNumber = 0;
            OnScreen = 0;
            op = 0;
        }
        
}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

